import React, { useEffect, useMemo, useState } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import 'react-leaflet-markercluster/dist/styles.min.css'
import MarkerClusterGroup from 'react-leaflet-markercluster'
import useSWR from 'swr'
import fetcher from '../../lib/fetcher'

const SPECIES_COLOR = { 'Abborre':'#1f77b4', 'Gädda':'#ff7f0e', 'Sik':'#2ca02c', 'default':'#6b7280' }

function createIcon(color){
  const svg = encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24"><path fill="${color}" d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5" fill="white"/></svg>`)
  return L.divIcon({ html: `<img src="data:image/svg+xml;utf8,${svg}" />`, className: '', iconSize: [36,36], iconAnchor: [18,36] })
}

function GeolocateButton(){
  const map = useMap()
  return (
    <button
      onClick={() => {
        if (!navigator.geolocation) return alert('Geolocation not supported')
        navigator.geolocation.getCurrentPosition((pos) => {
          const { latitude, longitude } = pos.coords
          map.setView([latitude, longitude], 13)
          L.marker([latitude, longitude]).addTo(map).bindPopup('Du är här').openPopup()
        }, (err) => alert('Kunde inte hitta plats: ' + err.message))
      }}
      className="absolute z-20 right-4 top-4 bg-white p-2 rounded shadow"
      title="Hitta mig"
    >
      📍
    </button>
  )
}

export default function EnhancedClusteredMarkersClient({ filters }: any) {
  const { data } = useSWR('/api/catch-reports', fetcher, { refreshInterval: 30*1000 })
  const [markers, setMarkers] = useState<any[]>([])

  useEffect(() => {
    if (!data) return
    const sinceDate = new Date()
    sinceDate.setDate(sinceDate.getDate() - (filters.days || 90))

    const filtered = (data as any[]).filter(r => {
      if (filters.species && filters.species !== '' && r.species.toLowerCase() !== filters.species.toLowerCase()) return false
      if (filters.method && filters.method !== '' && r.method && r.method.toLowerCase() !== filters.method.toLowerCase()) return false
      if (new Date(r.caught_at) < sinceDate) return false
      return true
    })
    setMarkers(filtered)
  }, [data, filters])

  const icons = useMemo(() => {
    const map = {}
    Object.entries(SPECIES_COLOR).forEach(([s,c]) => map[s] = createIcon(c))
    map['default'] = createIcon(SPECIES_COLOR.default)
    return map
  }, [])

  return (
    <MapContainer center={[59.33,18.07]} zoom={9} style={{ height: '100%', width: '100%' }}>
      <TileLayer attribution='&copy; OpenStreetMap' url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' />
      <GeolocateButton />
      <MarkerClusterGroup chunkedLoading showCoverageOnHover={false} spiderfyOnMaxZoom={true}>
        {markers.map(m => {
          const icon = icons[m.species] || icons['default']
          return (
            <Marker key={m.id} position={[m.lat, m.lon]} icon={icon}>
              <Popup>
                <div style={{minWidth:200}}>
                  <strong>{m.species}</strong> — {m.weight ? `${m.weight} kg` : 'okänd vikt'}<br/>
                  {m.method} · {m.caught_at}<br/>
                  <div style={{marginTop:8}}>{m.notes}</div>
                  <div style={{marginTop:8}}>
                    <a className="underline" href={`https://www.google.com/maps/dir/?api=1&destination=${m.lat},${m.lon}`} target="_blank" rel="noreferrer">Visa rutt</a>
                  </div>
                </div>
              </Popup>
            </Marker>
          )
        })}
      </MarkerClusterGroup>
    </MapContainer>
  )
}
