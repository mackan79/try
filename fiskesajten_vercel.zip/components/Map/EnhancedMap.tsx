import dynamic from 'next/dynamic'
import { useState } from 'react'
import FiltersPanel from '../UI/FiltersPanel'

const ClientMap = dynamic(() => import('./EnhancedClusteredMarkersClient'), { ssr: false })

export default function EnhancedMap() {
  const [filters, setFilters] = useState({ species: '', method: '', days: 90 })
  return (
    <div className="w-full h-full flex flex-col md:flex-row">
      <div className="md:w-72 p-2">
        <FiltersPanel filters={filters} setFilters={setFilters} />
      </div>
      <div className="flex-1 h-96 md:h-auto">
        <ClientMap filters={filters} />
      </div>
    </div>
  )
}
