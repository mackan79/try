export default function FiltersPanel({ filters, setFilters }: any) {
  return (
    <div className="bg-white p-3 rounded shadow space-y-3">
      <h3 className="font-semibold">Filter</h3>
      <label className="block">
        <span className="text-sm">Art</span>
        <input className="w-full mt-1 input" value={filters.species} onChange={(e) => setFilters({...filters, species: e.target.value})} />
      </label>
      <label className="block">
        <span className="text-sm">Metod</span>
        <input className="w-full mt-1 input" value={filters.method} onChange={(e) => setFilters({...filters, method: e.target.value})} />
      </label>
      <label className="block">
        <span className="text-sm">Senaste dagar</span>
        <input type="range" min={1} max={365} value={filters.days} onChange={(e) => setFilters({...filters, days: Number(e.target.value)})} />
        <div className="text-xs mt-1">{filters.days} dagar</div>
      </label>
    </div>
  )
}
