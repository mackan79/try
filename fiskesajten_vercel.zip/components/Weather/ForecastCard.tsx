export default function ForecastCard({ day }: any) {
  const date = new Date(day.dt * 1000).toLocaleDateString('sv-SE', { weekday: 'short', day: 'numeric', month: 'short' })
  return (
    <div className="flex items-center gap-3 p-2 border rounded-md">
      <div className="w-12 text-center">
        <div className="text-sm font-medium">{date}</div>
        <div className="text-xs">{day.weather?.[0]?.main}</div>
      </div>
      <div className="flex-1 text-sm text-slate-700">{day.weather?.[0]?.description}</div>
      <div className="text-sm font-semibold">{Math.round(day.temp.min)}° / {Math.round(day.temp.max)}°</div>
    </div>
  )
}
