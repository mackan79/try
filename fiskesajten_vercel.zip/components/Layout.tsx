import React from 'react'

export default function Layout({ children }: any){
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="bg-gradient-to-r from-sky-600 to-emerald-400 p-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <h1 className="text-white text-xl font-semibold">Fiskesajten</h1>
        </div>
      </header>
      <main>{children}</main>
      <footer className="py-6 text-center text-sm text-slate-500">© {new Date().getFullYear()} Fiskesajten</footer>
    </div>
  )
}
