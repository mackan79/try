# Fiskesajten — Prototype

Detta repo innehåller en Next.js + TypeScript prototype för en fiskesajt med:
- Leaflet-karta med klustring och artfärgning
- Postgres + PostGIS schema (migrations)\- Nappkalender-algoritm (moon, weather, historik)

Se `.env.local.example` för miljövariabler.
