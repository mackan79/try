export function moonPhaseFraction(year:number, month:number, day:number): number {
  const r = Date.UTC(year, month-1, day)/86400000.0
  const synodicMonth = 29.53058867
  const knownNew = Date.UTC(2000,0,6)/86400000.0
  const diff = r - knownNew
  const phase = (diff % synodicMonth) / synodicMonth
  return phase < 0 ? phase + 1 : phase
}
export function moonPhaseName(fraction:number){
  if (fraction < 0.0625 || fraction >= 0.9375) return 'New Moon'
  if (fraction < 0.1875) return 'Waxing Crescent'
  if (fraction < 0.3125) return 'First Quarter'
  if (fraction < 0.4375) return 'Waxing Gibbous'
  if (fraction < 0.5625) return 'Full Moon'
  if (fraction < 0.6875) return 'Waning Gibbous'
  if (fraction < 0.8125) return 'Last Quarter'
  return 'Waning Crescent'
}
