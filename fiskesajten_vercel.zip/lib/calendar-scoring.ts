import { moonPhaseFraction } from './moon'

export function scoreDay({ date, historicalCount, historicalMax, weather, species }: any) {
  const histNorm = historicalMax > 0 ? Math.min(1, historicalCount / historicalMax) : 0
  const [y, m, d] = date.split('-').map(Number)
  const moon = moonPhaseFraction(y,m,d)
  const speciesLower = (species||'').toLowerCase()
  let speciesMoonBias = 1.0
  if (speciesLower.includes('gädda')) speciesMoonBias = 1.10
  if (speciesLower.includes('abborre') || speciesLower.includes('abbor')) speciesMoonBias = 1.02
  if (speciesLower.includes('sik')) speciesMoonBias = 0.98

  const moonEffect = 1 - Math.abs(moon - 0.5) * 0.8
  const moonScore = Math.min(1, moonEffect * speciesMoonBias)

  let weatherScore = 1.0
  if (weather) {
    if (typeof weather.pressureTrend === 'number') {
      const t = -weather.pressureTrend
      weatherScore *= 1 + Math.max(-0.25, Math.min(0.45, t * 0.02))
    }
    if (typeof weather.windSpeed === 'number') {
      const w = weather.windSpeed
      if (w > 12) weatherScore *= 0.65
      else if (w > 8) weatherScore *= 0.85
    }
  }

  const wHist = 0.40, wMoon = 0.25, wWeather = 0.25, wSeason = 0.10

  const month = Number(date.split('-')[1])
  const seasonFactor = (month===1||month===2||month===12) ? 1.1 : (month>=6 && month<=8 ? 0.85 : 1.0)

  const raw = (histNorm * wHist) + (moonScore * wMoon) + (weatherScore * wWeather) + (seasonFactor * wSeason)
  const score = Math.round(Math.min(1, raw) * 100)

  return {
    date,
    score,
    breakdown: { hist: histNorm, moon: moonScore, weather: weatherScore, season: seasonFactor },
  }
}
