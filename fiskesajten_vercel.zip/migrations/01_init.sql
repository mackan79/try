-- 01_init.sql
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE,
  display_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS places (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  geom GEOMETRY(POINT, 4326) NOT NULL,
  tags TEXT[],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS catch_reports (
  id BIGSERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id) ON DELETE SET NULL,
  species TEXT NOT NULL,
  weight NUMERIC(6,2),
  method TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  caught_at DATE NOT NULL,
  geom GEOMETRY(POINT, 4326) NOT NULL,
  lat NUMERIC(10,6) GENERATED ALWAYS AS (ST_Y(geom::geometry)) STORED,
  lon NUMERIC(10,6) GENERATED ALWAYS AS (ST_X(geom::geometry)) STORED
);

CREATE INDEX IF NOT EXISTS idx_catch_reports_geom ON catch_reports USING GIST(geom);
CREATE INDEX IF NOT EXISTS idx_catch_reports_species ON catch_reports(species);
CREATE INDEX IF NOT EXISTS idx_catch_reports_caught_at ON catch_reports(caught_at);
