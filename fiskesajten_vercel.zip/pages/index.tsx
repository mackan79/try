import Layout from '../components/Layout'
import dynamic from 'next/dynamic'
import EnhancedMap from '../components/Map/EnhancedMap'
import useSWR from 'swr'
import fetcher from '../lib/fetcher'
import ForecastCard from '../components/Weather/ForecastCard'

export default function Home() {
  const { data: forecast } = useSWR('/api/weather?days=5&lat=59.33&lon=18.07', fetcher, { refreshInterval: 60*1000 })

  return (
    <Layout>
      <div className="p-4 max-w-5xl mx-auto">
        <h1 className="text-2xl font-semibold mb-3">Fiskesajten — Hem</h1>
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="md:col-span-2 bg-white p-3 rounded shadow">
            <h2 className="font-medium mb-2">Karta & fångstrapporter</h2>
            <div className="h-72 md:h-96">
              <EnhancedMap />
            </div>
          </div>
          <div className="bg-white p-3 rounded shadow">
            <h2 className="font-medium mb-2">5-dygns väder</h2>
            {forecast ? (
              <div className="space-y-2">
                {forecast.daily.slice(0,5).map((d: any, i: number) => (
                  <ForecastCard key={i} day={d} />
                ))}
              </div>
            ) : <div>Laddar väder...</div>}
          </div>
        </section>
      </div>
    </Layout>
  )
}
