import type { NextApiRequest, NextApiResponse } from 'next'
import pool from '../../lib/db'
import fetch from 'node-fetch'
import { scoreDay } from '../../lib/calendar-scoring'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { lat, lon, radius = 20000, species = '', years = 5 } = req.query
    if (!lat || !lon) return res.status(400).json({ error: 'Missing lat/lon' })

    const sql = `
      SELECT to_char(caught_at, 'MM-DD') as mmdd, COUNT(*) as cnt
      FROM catch_reports
      WHERE ST_DWithin(geom::geography, ST_SetSRID(ST_MakePoint($1,$2),4326)::geography, $3)
        AND caught_at >= (CURRENT_DATE - ($4 * interval '1 year'))
        ${species ? `AND lower(species)=lower($5)` : ''}
      GROUP BY mmdd
    `
    const params = species ? [Number(lon), Number(lat), Number(radius), Number(years), String(species)] : [Number(lon), Number(lat), Number(radius), Number(years)]
    const histResult = await pool.query(sql, params)
    const countsByMMDD = {}
    let maxCount = 0
    histResult.rows.forEach((r:any) => { countsByMMDD[r.mmdd] = Number(r.cnt); if (Number(r.cnt) > maxCount) maxCount = Number(r.cnt) })

    // fetch weather forecast
    const base = process.env.NEXT_PUBLIC_BASE_URL || ''
    const weatherResp = await fetch(`${base}/api/weather?lat=${lat}&lon=${lon}`)
    const weatherJson = await weatherResp.json()
    const weatherByDate = {}
    if (weatherJson && weatherJson.daily) {
      for (let i=0;i<weatherJson.daily.length;i++){
        const cur = weatherJson.daily[i], prev = weatherJson.daily[i-1]
        const date = new Date(cur.dt*1000).toISOString().slice(0,10)
        weatherByDate[date] = { pressure: cur.pressure, windSpeed: cur.wind_speed, temp: cur.temp?.day ?? null, pressureTrend: prev ? (cur.pressure - prev.pressure) : 0 }
      }
    }

    const out = []
    const today = new Date()
    const days = 30
    for (let i=0;i<days;i++){
      const dt = new Date(today); dt.setDate(today.getDate()+i)
      const dateStr = dt.toISOString().slice(0,10)
      const mmdd = dateStr.slice(5)
      const histCount = countsByMMDD[mmdd] || 0
      const sc = scoreDay({ date: dateStr, historicalCount: histCount, historicalMax: maxCount, weather: weatherByDate[dateStr], species: String(species || '') })
      out.push(sc)
    }

    return res.status(200).json({ calendar: out })
  } catch (err:any) {
    console.error(err)
    return res.status(500).json({ error: err.message || 'failed' })
  }
}
