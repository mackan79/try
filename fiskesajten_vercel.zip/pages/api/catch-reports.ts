import type { NextApiRequest, NextApiResponse } from 'next'
import pool from '../../lib/db'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    try {
      const { lat, lon, radius = 50000, species } = req.query
      if (lat && lon) {
        const sql = `
          SELECT id, species, weight, method, notes, caught_at, ST_Y(geom) AS lat, ST_X(geom) AS lon
          FROM catch_reports
          WHERE ST_DWithin(geom::geography, ST_SetSRID(ST_MakePoint($1,$2),4326)::geography, $3)
          ${species ? 'AND lower(species)=lower($4)' : ''}
          ORDER BY caught_at DESC
          LIMIT 1000
        `
        const params = species ? [Number(lon), Number(lat), Number(radius), String(species)] : [Number(lon), Number(lat), Number(radius)]
        const r = await pool.query(sql, params)
        return res.status(200).json(r.rows)
      } else {
        // return recent global reports (caution: for demo only)
        const r = await pool.query('SELECT id, species, weight, method, notes, caught_at, ST_Y(geom) AS lat, ST_X(geom) AS lon FROM catch_reports ORDER BY caught_at DESC LIMIT 500')
        return res.status(200).json(r.rows)
      }
    } catch (err:any) {
      console.error(err)
      return res.status(500).json({ error: err.message || 'failed' })
    }
  }

  if (req.method === 'POST') {
    try {
      const { species, weight, method, notes, lat, lon, caught_at } = req.body
      if (!species || !lat || !lon || !caught_at) return res.status(400).json({ error: 'Missing fields' })
      const sql = `INSERT INTO catch_reports (species, weight, method, notes, caught_at, geom) VALUES ($1,$2,$3,$4,$5, ST_SetSRID(ST_MakePoint($6,$7),4326)) RETURNING id`
      const params = [species, weight || null, method || null, notes || null, caught_at, Number(lon), Number(lat)]
      const r = await pool.query(sql, params)
      return res.status(201).json({ id: r.rows[0].id })
    } catch (err:any) {
      console.error(err)
      return res.status(500).json({ error: err.message || 'failed' })
    }
  }

  res.setHeader('Allow', ['GET','POST'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}
