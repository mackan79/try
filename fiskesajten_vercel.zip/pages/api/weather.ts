import type { NextApiRequest, NextApiResponse } from 'next'
import axios from 'axios'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    const { lat='60.128161', lon='18.643501' } = req.query
    const key = process.env.OPENWEATHER_API_KEY
    if (!key) return res.status(500).json({ error: 'Missing OPENWEATHER_API_KEY' })
    const url = `https://api.openweathermap.org/data/2.5/onecall?lat=${lat}&lon=${lon}&exclude=minutely,hourly,alerts&units=metric&appid=${key}`
    const r = await axios.get(url)
    return res.status(200).json(r.data)
  } catch (err:any) {
    console.error(err)
    return res.status(500).json({ error: err.message || 'failed' })
  }
}
